package com.klef.jfsd.springboot.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.klef.jfsd.springboot.model.Admin;
import com.klef.jfsd.springboot.model.Employee;
import com.klef.jfsd.springboot.model.Patient;
import com.klef.jfsd.springboot.service.AdminService;
import com.klef.jfsd.springboot.service.EmployeeService;
import com.klef.jfsd.springboot.service.PatientService;

@Controller
public class ClientController
{
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private PatientService patientservice;
	
	
	@GetMapping("/")
	public String mainhomedemo()
	{
		return "index";
	}
	
	@GetMapping("/adminlogin")
	public ModelAndView adminlogindemo()
	{
		ModelAndView mv = new ModelAndView("adminlogin");
		
		return mv;
	}
	
	@GetMapping("/employeelogin")
	public ModelAndView employeeogindemo()
	{
		ModelAndView mv = new ModelAndView("employeelogin");
		
		return mv;
	}
	
	@GetMapping("/plogin")
	public ModelAndView plogindemo()
	{
		ModelAndView mv = new ModelAndView("plogin");
		
		return mv;
	}
	
	@GetMapping("/employeereg")
	public ModelAndView employeeregdemo()
	{
		ModelAndView mv = new ModelAndView("employeeregistration", "emp",new Employee());
		return mv;
	}
	
	@GetMapping("/psignup")
	  public ModelAndView psignupdemo()
	  {
	    ModelAndView mv = new ModelAndView("psignup", "p",new Patient());
	    return mv;
	  }
	
	@GetMapping("/adminhome")
	public ModelAndView adminhomedemo()
	{
		ModelAndView mv = new ModelAndView("adminhome");
		
		return mv;
	}
	
	@GetMapping("/employeehome")
	public ModelAndView employeehomedemo(HttpServletRequest request)
	{
		ModelAndView mv = new ModelAndView("employeehome");
		
		HttpSession session = request.getSession();
		
		String euname = (String) session.getAttribute("euname");
		
		mv.addObject("euname", euname);
		
		return mv;
	}
	
	@GetMapping("/phome")
	public ModelAndView phomedemo(HttpServletRequest request)
	{
	    ModelAndView mv = new ModelAndView("phome");
	    
	    HttpSession session = request.getSession();
	    
	    String puname = (String) session.getAttribute("puname");
	    
	    mv.addObject("puname", puname);
	    
	    return mv;
	  }
	
	@GetMapping("/viewallemps")
	public ModelAndView viewallempsdemo()
	{
		ModelAndView mv = new ModelAndView("viewallemployees");
		
		List<Employee> emplist = adminService.viewallemployees();
		mv.addObject("emplist",emplist);
		
		return mv;
	}
	
	@PostMapping("/checkadminlogin")
	public ModelAndView checkadminlogindemo(HttpServletRequest request)
	{
		ModelAndView mv =  new ModelAndView();
		
		String auname = request.getParameter("auname");
		String apwd = request.getParameter("apwd");
		
		Admin admin = adminService.checkadminlogin(auname, apwd);
		
		if(admin!=null)
		{
			
			HttpSession session = request.getSession();
			
			session.setAttribute("auname", auname);
			
			mv.setViewName("adminhome");
		}
				else
		{
			mv.setViewName("adminlogin");
			mv.addObject("msg", "Login Failed");
		}
		
		
		return mv;
	}
	
	
	@PostMapping("/checkemplogin")
	public ModelAndView checkemplogindemo(HttpServletRequest request)
	{
		ModelAndView mv =  new ModelAndView();
		
		String euname = request.getParameter("euname");
		String epwd = request.getParameter("epwd");
		
		Employee emp = employeeService.checkemplogin(euname, epwd);
		
		if(emp!=null)
		{
			HttpSession session = request.getSession();
			
			session.setAttribute("euname", euname);
			
			mv.setViewName("employeehome");
		}
		else
		{
			mv.setViewName("employeelogin");
			mv.addObject("msg", "Login Failed");
		}
		
		
		return mv;
	}
	
	@PostMapping("/checkpatientlogin")
	  public ModelAndView checkpatientlogindemo(HttpServletRequest request)
	  {
	    ModelAndView mv =  new ModelAndView();
	    
	    String puname = request.getParameter("puname");
	    String ppwd = request.getParameter("ppwd");
	    
	    Patient pat = patientservice.checkpatientlogin(puname, ppwd);
	    
	    if(pat!=null)
	    {
	      HttpSession session = request.getSession();
	      session.setAttribute("puname", puname);
	      mv.setViewName("phome");
	    }
	    else
	    {
	      mv.setViewName("plogin");
	      mv.addObject("msg", "Please enter valid details.");
	    } 
	    return mv;
	  }
	
	@PostMapping("/addemployee")
	public String addemployeedemo(@ModelAttribute("emp") Employee employee)
	{
		employeeService.addemployee(employee);
		
//		ModelAndView mv = new ModelAndView();
//		mv.setViewName("employeeregistration");
//		mv.addObject("msg", "Employee Registered Successfully");
		
		return "redirect:employeelogin";
	}
	
	@RequestMapping(value="/addpatient", method = RequestMethod.GET)
	  public String addpatientdemo(@ModelAttribute("pat") Patient patient)
	  {
	    patientservice.addpatient(patient);
//	    
//	    ModelAndView mv = new ModelAndView();
//	    mv.setViewName("psignup");
//	    mv.addObject("msg", "Patient Registered Successfully");
	    
	    return "redirect:plogin";
	  }
	
	@GetMapping("/deleteemp")
	public String deleteempdemo(@RequestParam("id") int eid)
	{
		adminService.deleteemployee(eid);
		
		return "redirect:viewallemps";
	}
	
	@GetMapping("/viewemp")
	public ModelAndView viewemp(HttpServletRequest request)
	{
		HttpSession session = request.getSession();
		
		String euname = (String) session.getAttribute("euname");
		
		Employee emp =  employeeService.viewemployee(euname);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("viewemployee");
		mv.addObject("emp",emp);
		
		return mv;
	}
	
	@GetMapping("/viewpatient")
	  public ModelAndView viewhtl(HttpServletRequest request)
	  {
	    HttpSession session = request.getSession();
	    
	    String puname = (String) session.getAttribute("puname");
	    
	    Patient pat =  patientservice.viewpatient(puname);
	    
	    ModelAndView mv = new ModelAndView();
	    mv.setViewName("viewpatient");
	    mv.addObject("pat",pat);
	    
	    return mv;
	  }
	
	@GetMapping("/echangepwd")
	public ModelAndView echangepwd(HttpServletRequest request)
	{
		HttpSession session = request.getSession();
		
		String euname = (String) session.getAttribute("euname");
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("empchangepwd");
		mv.addObject("euname",euname);
		
		return mv;
	}
	
	@GetMapping("/changepatientpassword")
	  public ModelAndView htlchangepwd(HttpServletRequest request)
	  {
	    HttpSession session = request.getSession();
	    
	    String puname = (String) session.getAttribute("puname");
	    
	    ModelAndView mv = new ModelAndView();
	    mv.setViewName("changepatientpassword");
	    mv.addObject("puname",puname);
	    
	    return mv;
	  }
	
	@PostMapping("/updateemppwd")
	public ModelAndView updateemppwddemo(HttpServletRequest request)
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("empchangepwd");
		
		HttpSession session = request.getSession();
		
		String euname = (String) session.getAttribute("euname");
		
		String eoldpwd = request.getParameter("eopwd");
		String enewpwd = request.getParameter("enpwd");
		
		int n = employeeService.changeemployeepassword(eoldpwd, enewpwd, euname);
		
		if(n > 0)
		{
			
			mv.addObject("msg","Password Updated Successfully");
		}
		else
		{
			mv.addObject("msg","Old Password is Incorrect");
		}
		
		return mv;
	}
	
	@PostMapping("/updatepatientpwd")
	public ModelAndView updatehtlpwddemo(HttpServletRequest request)
	{
	    ModelAndView mv = new ModelAndView();
	    mv.setViewName("changepatientpassword");
	    HttpSession session = request.getSession();
	    String puname = (String) session.getAttribute("puname");
	    String poldpwd = request.getParameter("popwd");
	    String pnewpwd = request.getParameter("pnpwd");
	    int n = patientservice.changepatientpassword(poldpwd, pnewpwd, puname);
	    if(n > 0)
	    {
	    	mv.addObject("msg","Password Updated Successfully");
	    }
	    else
	    {
	    	mv.addObject("msg","Old Password is Incorrect");
	    }
	    return mv;
	}
	
	@GetMapping("/viewempbyid")
	public ModelAndView viewempbyiddemo(@RequestParam("id") int eid)
	{
		Employee emp = adminService.viewemployeebyid(eid);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("viewempbyid");
		mv.addObject("emp",emp);
		return mv;
	}	
}