package com.klef.jfsd.springboot.service;
import com.klef.jfsd.springboot.model.Patient;

public interface PatientService 
{
	public Patient addpatient(Patient patient);
	public Patient checkpatientlogin(String uname,String pwd);
	public Patient viewpatient(String uname);
	public int changepatientpassword(String poldpwd,String pnewpwd,String puname);

}