package com.klef.jfsd.springboot.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.klef.jfsd.springboot.model.Patient;
import com.klef.jfsd.springboot.repository.PatientRepository;

@Service
public class PatientServiceImpl implements PatientService
{
	@Autowired
	private PatientRepository patientRepository;
	
	@Override
	public Patient addpatient(Patient patient)
	{
		return patientRepository.save(patient);		
	}

	@Override
	public Patient checkpatientlogin(String uname, String pwd) 
	{
		return patientRepository.checkpatientlogin(uname, pwd);
	}

	@Override
	public Patient viewpatient(String uname) 
	{
		
		return patientRepository.viewpatient(uname);
	}

	@Override
	public int changepatientpassword(String poldpwd, String pnewpwd, String puname)
	{
		return patientRepository.updatepatientpassword(pnewpwd, poldpwd, puname);
	}

}